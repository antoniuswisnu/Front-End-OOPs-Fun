import React, { Component, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login-register.css"

const SignIn=()=>{

  const [email, setEmail]=useState("");
  const [password, setPassword]=useState("");
  const nav = useNavigate();

  const LogIn = async () =>{
    let result = await fetch("http://127.0.0.1:8080/login", {
      method:"post",
      body:JSON.stringify({email, password}),
      headers:{
        'Content-Type':'application/json'
      }
    }).then((response) => response.json())
    .then( response => {
      return response;
    })
    if (result.email){
      if (result.roles == "teacher"){
        nav("/dashboard/create-class");
      }else{
        alert("berhasil masuk sebaga siswa");
      }
    }else{
      alert("belum berhasil masuk");
    }
  }

  return (
    <form>
      <h3>Sign In</h3>

      <div className="mb-3">
        <label>Email address</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-control" placeholder="Enter email" />
      </div>

      <div className="mb-3">
        <label>Password</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="form-control" placeholder="Enter password" />
      </div>

      <div className="d-grid">
        <button type="button" onClick={LogIn} className="btn btn-primary">
          Submit
        </button>
      </div>
      <p className="forgot-password text-right">
        Already Have an Account? <a href="/register">Register</a>
      </p>
      <p className="forgot-password text-right">
        Go to <a href="/home">Sidebar</a>
      </p>
    </form>

    
  );

}

export default SignIn;
      

