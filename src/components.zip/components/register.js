import React, { Component, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login-register.css"


const SignUp=()=>{
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [password2,setPassword2]=useState("");
  const [roles,setRoles]=useState("");
  const navigate = useNavigate();
  const collectData= async ()=>{
    if (password == password2){
      let result = await fetch("http://127.0.0.1:8080/register", {
      method:'post',
      body: JSON.stringify({name, email, password, roles}),
      headers:{
        'Content-Type':'application/json'
      }
    })
    result = result.json();
    console.warn(result);
    navigate("/");
    }else{
      alert("Password must be same!");
    }
    
  }

  return(
    <form name="signUp-form">
        <h3>Sign Up</h3>

        <div className="mb-3">
          <label>Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="form-control" placeholder="Name" />
        </div>

        {/* <div className="mb-3">
          <label>Last name</label>
          <input type="text" className="form-control" placeholder="Last name" />
        </div> */}

        <div className="mb-3">
          <label>Email address</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-control" placeholder="Enter email" />
        </div>

        <div className="mb-3">
          <label>Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="form-control" placeholder="Enter password" />
        </div>

        
        <div className="mb-3">
          <label>Confirm Password</label>
          <input type="password" value={password2} onChange={(e) => setPassword2(e.target.value)} className="form-control" placeholder="Confirm password" />
          <p class="error confirm-password-error"></p>
        </div>

        <div className="mb-3">
          <label>roles</label><br></br>
          <input type="radio" id="teacher" name="roles" value={roles} onChange={(e) => setRoles("teacher")}/>
          <label htmlFor="roles">Teacher</label> &ensp;
          <input type="radio" id="student" name="roles" value={roles} onChange={(e) => setRoles("student")}/>

          
          <label htmlFor="roles">Student</label>
        </div>

        <div className="d-grid">
          <button onClick={collectData} type="button" className="btn btn-primary">
            Sign Up
          </button>
        </div>
        <p className="forgot-password text-right">
          Already registered <a href="/sign-in">sign in?</a>
        </p>
      </form>
  )
}
export default SignUp;